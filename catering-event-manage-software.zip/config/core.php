<?php

return [
    'image' => [
        'default' => [
        	'logo2d' => '/assets/uploads/default/logo.png',
        	'logo3d' => '/assets/uploads/default/logo.png',
            'avatar' => '/assets/uploads/default/avatar.jpg',
            'cover'  => '/assets/uploads/default/cover.png',
        ]
    ],
];