<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ThemeItem extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'source', 'category'];
    
    public $timestamps = false;
}
