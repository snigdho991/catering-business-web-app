    

    <?php $__env->startSection('content'); ?>
        
   
   
        <div class="row">
            <div class="col-sm-8">
                <h4>OutBox</h4>
                
            </div>
        </div>

<div class="table-responsive">


<table id="example" class="display" style="width:100%">
    <thead>
        <tr>
            <th>#</th>
            <th>Phone Number</th>
            <th>Message</th>
            
            <th>Message Id</th>
            <th>Status</th>
            <th>TAT</th>
            <th>Delivery date</th>
            <th>Date</th>
            
        </tr>
    </thead>
    <tbody>
        <?php if(!empty($messages) && $messages->count()): ?>
        <?php $count=0 ?>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $count++ ?>
                <tr>
                    <td><?php echo e($count); ?></td>
                    <td><?php echo e($value->phone_number); ?></td>
                    <td><?php echo e($value->text_message); ?></td>
                    
                    <td><?php echo e($value->message_id); ?></td>
                    
                    <td><?php echo e($value->status); ?></td>
                    <td><?php echo e($value->delivery_tat); ?></td>
                    <td><?php echo e($value->delivery_time); ?></td>
                    <td><?php echo e($value->created_at); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="10">There are no data.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
</div>
   

<?php echo e($messages->links("pagination::bootstrap-4")); ?>



 <?php $__env->stopSection(); ?>

<?php echo $__env->make('royceviews::base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel Projects\catering-event-manage-software\vendor\royceltd\laravel-bulksms\src/../resources/views/textmessages.blade.php ENDPATH**/ ?>