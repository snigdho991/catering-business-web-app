
<?php $__env->startSection('title', 'Inbox'); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0 font-size-18">Chat <?php if(Auth::user()->hasRole('Manager')): ?> With Customers <?php elseif(Auth::user()->hasRole('Customer')): ?> With Manager <?php endif; ?></h4>

                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                <li class="breadcrumb-item active">Chat <?php if(Auth::user()->hasRole('Manager')): ?> With Customers <?php elseif(Auth::user()->hasRole('Customer')): ?> With Manager <?php endif; ?></li>
                            </ol>
                        </div>

                    </div>
                </div>
            </div>
            <!-- end page title -->

            	
            <chat :user="<?php echo e(auth()->user()); ?>"></chat>
            	
            <!-- end row -->
            
        </div> <!-- container-fluid -->
    </div>
                <!-- End Page-content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(mix('/js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
    .feed {
        width: 100%;
        height: 486px;
        overflow: hidden !important;
        overflow-y: scroll !important;
    }

    .ctext-wrap-mbb {
        margin-bottom: 20px !important;
    }
  </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel Projects\catering-event-manage-software\resources\views/message/inbox.blade.php ENDPATH**/ ?>