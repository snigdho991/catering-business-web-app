    

    <?php $__env->startSection('content'); ?>
        
   
   
        <div class="row">
            <div class="col-sm-12 text-center">
                <h4>Send to groups</h4>
                
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <div class="alert alert-secondary alert-dismissible fade show" role="alert">
   If you would like to customize text for example Hello John ..... allow to use of salutation
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>
            </div>
        </div>

        <form method="POST" action="<?php echo e(url('bulksms/group-text')); ?>">
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="col-sm-4">
                <div class="form-group">
                    <label>
                        Message
                    </label>
                    <textarea class="form-control pull-left" name="message" rows="5" required></textarea>
                </div>
            </div>
            <div class="col-sm-5">
                <div class="form-group">
                    

                    
                        <br />

                        <table>
                            
                            <tr>
                                <td>
                                    Include Salutation ?
                                    
                                </td>
                                <td>
                                    <td>

                                    <div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="salutation" id="inlineRadio1" value="Yes" checked>
  <label class="form-check-label" for="inlineRadio1">Yes</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="salutation" id="inlineRadio2" value="No">
  <label class="form-check-label" for="inlineRadio2">No</label>
</div>

                                </td>
                                    
                                </td>
                                
                            </tr>
                            <tr>
                                <td>
                                     &nbsp;
                                </td>
                               
                            </tr>
                            <tr>
                                <td>
                                    <input type="checkbox" id="checkAll" /> Select all ( <?php echo count($groups) ?>)
                                    
                                </td>
                                
                            </tr>
                        </table>
                        <div>
                            

                        </div>
                        

                    
                    <label>
                        Groups
                    </label>
                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <br />
                    <span class="float-left">
                        
                        <input type="checkbox" value="<?php echo e($item->id); ?>" name="groups[]" /> <?php echo e($item->name); ?>

                    </span>
                    
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="form-group">
                    
                    <input type="submit" class="btn btn-primary" value="Send SMS" />
                </div>
            </div>

        </div>
            </div>
        </form>

   


<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('royceviews::base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel Projects\catering-event-manage-software\vendor\royceltd\laravel-bulksms\src/../resources/views/grouptext.blade.php ENDPATH**/ ?>