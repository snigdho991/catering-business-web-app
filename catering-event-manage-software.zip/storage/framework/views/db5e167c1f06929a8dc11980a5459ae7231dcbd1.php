
<?php $__env->startSection('title', 'Manager Dashboard'); ?>

<?php $__env->startSection('content'); ?>

	<div class="page-content">
	    <div class="container-fluid">

            <?php if($pending->count() > 0 && $unreads->count() > 0): ?>

                <div class="alert alert-dismissible alert-warning " style="text-align: center; margin-bottom: 40px;padding: 4px;" role="alert">
                
                    <marquee direction="left" style="font-weight: 410;margin-top: 5px;font-size: 14.5px;">
                        <span style="color: #343a40!important"><i class="bx bx-bell bx-tada" style="position: relative; top: 1.5px;"></i> Notification:</span> <span class="badge bg-danger rounded-pill" style="position: relative; top: -1.5px;"><?php echo e($pending->count()); ?></span> <?php if($pending->count() > 1): ?> events haven't <?php else: ?> event hasn't <?php endif; ?> been assigned yet. Please <a style="color: #222;" target="_blank" href="<?php echo e(route('manager.not.assigned')); ?>">assign employee</a> to <?php if($pending->count() > 1): ?> these events <?php else: ?> the event <?php endif; ?> to get started.
                        <b class="text-primary">||</b>
                        <span style="color: #343a40!important"><i class="bx bx-bell bx-tada" style="position: relative; top: 1.5px;"></i> Message:</span> <span class="badge bg-danger rounded-pill" style="position: relative; top: -1.5px;"><?php echo e($unreads->count()); ?></span> <?php if($unreads->count() > 1): ?> messages haven't <?php else: ?> message hasn't <?php endif; ?> checked yet. Please <a style="color: #222;" target="_blank" href="<?php echo e(route('inbox')); ?>">read & reply</a> the message.
                    </marquee>
                    <button type="button" class="btn-close text-white" data-bs-dismiss="alert" aria-label="Close"></button>

                </div>

            <?php elseif($pending->count() > 0): ?>

                 <div class="alert alert-dismissible alert-warning " style="text-align: center; margin-bottom: 40px;padding: 4px;" role="alert">
                
                    <marquee direction="left" style="font-weight: 410;margin-top: 5px;font-size: 14.5px;">
                        <span style="color: #343a40!important"><i class="bx bx-bell bx-tada" style="position: relative; top: 1.5px;"></i> Notification:</span> <span class="badge bg-danger rounded-pill" style="position: relative; top: -1.5px;"><?php echo e($pending->count()); ?></span> <?php if($pending->count() > 1): ?> events haven't <?php else: ?> event hasn't <?php endif; ?> been assigned yet. Please <a style="color: #222;" target="_blank" href="<?php echo e(route('manager.not.assigned')); ?>">assign employee</a> to <?php if($pending->count() > 1): ?> these events <?php else: ?> the event <?php endif; ?> to get started.
                    </marquee>
                    <button type="button" class="btn-close text-white" data-bs-dismiss="alert" aria-label="Close"></button>

                </div>

            <?php elseif($unreads->count() > 0): ?>
            
                 <div class="alert alert-dismissible alert-warning " style="text-align: center; margin-bottom: 40px;padding: 4px;" role="alert">
                
                    <marquee direction="left" style="font-weight: 410;margin-top: 5px;font-size: 14.5px;">
                        <span style="color: #343a40!important"><i class="bx bx-bell bx-tada" style="position: relative; top: 1.5px;"></i> Message:</span> <span class="badge bg-danger rounded-pill" style="position: relative; top: -1.5px;"><?php echo e($unreads->count()); ?></span> <?php if($unreads->count() > 1): ?> messages haven't <?php else: ?> message hasn't <?php endif; ?> checked yet. Please <a style="color: #222;" target="_blank" href="<?php echo e(route('inbox')); ?>">read & reply</a> the message.
                    </marquee>
                    <button type="button" class="btn-close text-white" data-bs-dismiss="alert" aria-label="Close"></button>

                </div>
            <?php endif; ?>

	        <!-- start page title -->
	        <div class="row">
	            <div class="col-12">
	                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
	                    <h4 class="mb-sm-0 font-size-18"><?php echo e(Auth::user()->role); ?> Dashboard</h4>                      
	                </div>
	            </div>
	        </div>

	        <div class="row">
                <div class="col-xl-12">

                    
                    <!-- end row -->
                    <div class="row" id="deviceStandard" style="margin-top: -40px;;">
                        <div class="col-md-4"></div>
                        <div class="col-md-4" style="text-align: center !important;">
                            <span class="badge bg-dark font-size-12">Dashboard Stats <i class="bx bx-caret-down"></i></span><br><br>
                        </div>
                        <div class="col-md-4"></div>
                    </div>

                    <div class="row">

                        <div class="col-md-4">
                            <div class="card mini-stats-wid">
                                <div class="card-body">
                                    <div class="media">
                                        <div class="media-body">
                                            <p class="text-muted fw-medium">Total Customers</p>
                                            <h4 class="mb-0"><?php echo e($customers->count()); ?></h4>
                                        </div>

                                        <div class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                            <span class="avatar-title rounded-circle bg-primary">
                                                <i class="bx bx-copy-alt font-size-24"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="card mini-stats-wid">
                                <div class="card-body">
                                    <div class="media">
                                        <div class="media-body">
                                            <p class="text-muted fw-medium">Total Employees</p>
                                            <h4 class="mb-0"><?php echo e($employees->count()); ?></h4>
                                        </div>

                                        <div class="avatar-sm rounded-circle bg-primary align-self-center mini-stat-icon">
                                            <span class="avatar-title rounded-circle bg-primary">
                                                <i class="bx bx-archive-in font-size-24 "></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="card mini-stats-wid">
                                <div class="card-body">
                                    <div class="media">
                                        <div class="media-body">
                                            <p class="text-muted fw-medium">Total Events</p>
                                            <h4 class="mb-0"><?php echo e($events->count()); ?></h4>
                                        </div>

                                        <div class="mini-stat-icon avatar-sm rounded-circle bg-primary align-self-center">
                                            <span class="avatar-title">
                                                <i class="bx bx-purchase-tag-alt font-size-24"></i>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="theme_value" data-theme="<?php echo e(Auth::user()->theme); ?>"></div>
                    </div>

                </div>
            </div>
            <!-- end row -->

	    </div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style type="text/css">
        @media  screen and (max-width: 1199px) and (min-width: 300px) {
            #deviceStandard {
                margin-top: 10px !important;
            }
        }

        .alert-dismissible .btn-close {
            padding: 0.9rem 1.25rem !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel Projects\catering-event-manage-software\resources\views/backend/manager/index.blade.php ENDPATH**/ ?>