    

    <?php $__env->startSection('content'); ?>
        
   
   
        <div class="row">
            <div class="col-sm-12 text-center">
                <h4>Contact Groups</h4>
                
            </div>
        </div>
        <div class="table-responsive">

            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
 Add Group
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Contact Group</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo e(url('/bulksms/contacts-group')); ?>" method="POST">
        <?php echo e(csrf_field()); ?>

            
      <div class="modal-body">
          
            <div class="row">
                <div class="col-sm-8">
                    <label>Name <small style="color: red">*</small></label>
                    <input type="text" class="form-control" name="group" placeholder="Group Name"  required/>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-8">
                    <label>Description (Optional)</label>
                    <textarea class="form-control" name="description" placeholder="Group description (optional)"></textarea>
                    
                </div>
            </div>
        

        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      </form>
    </div>
  </div>
</div>


<table id="example" class="display" style="width:100%">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Contacts</th>
            <th>Description</th>
            <th>Date</th>
            <th>Action</th>
            
            
        </tr>
    </thead>
    <tbody>
        <?php if(!empty($groups) && $groups->count()): ?>
        <?php $count=0 ?>
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php $count++ ?>
                <tr>
                    <td><?php echo e($count); ?></td>
                    <td><?php echo e($value->name); ?></td>
                    <td><?php echo e($value->contacts_count); ?></td>
                    <td><?php echo e($value->description); ?></td>
                    
                    <td><?php echo e($value->created_at); ?></td>

                    <td>
                        <a href="<?php echo e(url('/bulksms/edit-group',$value->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td colspan="10">There are no data.</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
</div>

   


<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('royceviews::base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel Projects\catering-event-manage-software\vendor\royceltd\laravel-bulksms\src/../resources/views/contactgroups.blade.php ENDPATH**/ ?>