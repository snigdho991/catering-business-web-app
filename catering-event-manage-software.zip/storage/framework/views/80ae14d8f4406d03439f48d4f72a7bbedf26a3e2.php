
<!doctype html>
<html lang="en">

    <head>
            
        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>
        
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"> 
        <?php echo $__env->make('libs.meta-tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('libs.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('styles'); ?>

    </head>

    <body data-sidebar="dark">
        <div id="app">
            <?php if(url()->current() != url('/inbox')): ?>
                <div style="display: none !important;"><chat :user="<?php echo e(auth()->user()); ?>"></chat></div>
            <?php endif; ?>

            <?php if(Auth::check()): ?>

                <audio id="noty_audio">                    
                  <source src="<?php echo e(asset('audio/notify.mp3')); ?>">
                  <source src="<?php echo e(asset('audio/notify.oog')); ?>">
                  <source src="<?php echo e(asset('audio/notify.wav')); ?>">
                </audio>       

                <audio id="noty_audio_two">                    
                  <source src="<?php echo e(asset('audio/notify.mp3')); ?>">
                  <source src="<?php echo e(asset('audio/notify.oog')); ?>">
                  <source src="<?php echo e(asset('audio/notify.wav')); ?>">
                </audio>              
            
            <?php endif; ?> 

            <!-- <body data-layout="horizontal" data-topbar="dark"> -->

            <!-- Begin page -->
            
            <div id="layout-wrapper">
                
                <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                
                <!-- ========== Left Sidebar Start ========== -->
                <?php echo $__env->make('includes.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- Left Sidebar End -->           

                <!-- ========================== Main Content ==================================== -->
                <div class="main-content">

                    <?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                <!-- end main content-->

            </div>

            <!-- END layout-wrapper -->

                <!-- Right Sidebar -->
                <?php echo $__env->make('includes.right-themes', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- /Right-bar -->

            <!-- Right bar overlay-->
            <div class="rightbar-overlay"></div>
        </div>
        
        <!-- JAVASCRIPT -->
        <?php echo $__env->make('libs.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('scripts'); ?>

    </body>

</html>
<?php /**PATH H:\Laravel Projects\catering-event-manage-software\resources\views/layouts/master.blade.php ENDPATH**/ ?>