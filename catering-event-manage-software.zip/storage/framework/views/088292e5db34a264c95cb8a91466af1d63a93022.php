

 <!doctype html>
<html lang="en">

    
    <head>
        
        <meta charset="utf-8" />
        <title>Verify Email - <?php echo e(config('app.name')); ?></title>
        
        <?php echo $__env->make('libs.meta-tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('libs.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </head>

    <body>
        <span>
            <p style="margin-left: 20px; margin-top: 15px; font-weight:500">Hello, <span class="text-primary"> <?php echo e(auth()->user()->name); ?> </span></p>
            <form method="POST" action="<?php echo e(route('logout')); ?>" style="float: right; margin-top: -40px;">
                <?php echo csrf_field(); ?>

                <button type="submit" class="text-danger dropdown-item" style="font-weight: 500;">
                    <i class="bx bx-power-off font-size-16 align-middle me-1 text-danger"></i>

                    <span key="t-logout">
                        Log out
                    </span>                            
                </button>
            </form>
        </span>

        <div class="account-pages my-5 pt-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center mb-5">
                            <h1 class="display-2 fw-medium">N<i class="bx bx-buoy bx-spin text-danger display-3"></i>T</h1>
                            <h4 style="margin-top: -15px;"><span class="text-success">VERIFIED</span> YET</h4>
                            <h5 style="margin-top:15px;">Thanks for signing up! Before getting started, could you verify your email address by clicking on the link we just emailed to you? If you didn't receive the email, we will gladly send you another.
                                <br>
                                Please check your provided email address.</h5>

                            <?php if(session('status') == 'verification-link-sent'): ?>
                                <h5 class="text-success">
                                    <?php echo e(__('A new verification link has been sent to the email address you provided during registration.')); ?>

                                </h5>
                            <?php endif; ?>
                            <br>
                            <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                                <?php echo csrf_field(); ?>

                                <div>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.button','data' => ['type' => 'submit','class' => 'btn btn-dark']]); ?>
<?php $component->withName('jet-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'btn btn-dark']); ?>
                                        <?php echo e(__('Resend Verification Email')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </form>
                            
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-md-8 col-xl-6">
                        <div>
                            <img src="<?php echo e(asset('assets/images/error-img.png')); ?>" alt="" class="img-fluid">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('libs.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>

</html><?php /**PATH H:\Laravel Projects\catering-event-manage-software\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>