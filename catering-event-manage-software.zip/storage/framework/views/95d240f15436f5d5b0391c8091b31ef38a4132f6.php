<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <?php echo date("Y"); ?> © <?php echo e(config('app.name')); ?>.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design &amp; Develop by Shahid Events Teams
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH H:\Laravel Projects\catering-event-manage-software\resources\views/includes/footer.blade.php ENDPATH**/ ?>