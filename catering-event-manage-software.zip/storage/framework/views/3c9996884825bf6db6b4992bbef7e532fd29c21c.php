    

    <?php $__env->startSection('content'); ?>
        
   
   
        <div class="row">
            <div class="col-sm-12">
                <h4>Send Single Text</h4>

                
            </div>
        </div>
        <div class="alert alert-secondary">
            If you have contacts in excel, Copy column and past the box, There should be one phone number per line
        </div>

        <form action="<?php echo e(url('bulksms/single-text')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>


        
        <div class="row pull-left">
            <div class="col-sm-4">
                <div class="form-group">
                    <label>
                        Message
                    </label>
                    <textarea class="form-control pull-left" name="message" rows="5" required></textarea>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="form-group">
                    <label>
                        Phone Numbers
                    </label>
                    <textarea class="form-control" name="phone_numbers" rows="15" placeholder="Phone Numbers separated by new line e.g &#10;0713727937&#10;254739***657" required></textarea>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="form-group">
                    
                    <input type="submit" class="btn btn-primary" value="Send SMS" />
                </div>
            </div>

        </div>

        </form>

   


<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('royceviews::base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel Projects\catering-event-manage-software\vendor\royceltd\laravel-bulksms\src/../resources/views/singletext.blade.php ENDPATH**/ ?>