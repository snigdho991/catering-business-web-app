	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta content="Shahid Events" name="description" />
		<meta content="author" name="author" /><?php /**PATH H:\Laravel Projects\catering-event-manage-software\resources\views/libs/meta-tags.blade.php ENDPATH**/ ?>