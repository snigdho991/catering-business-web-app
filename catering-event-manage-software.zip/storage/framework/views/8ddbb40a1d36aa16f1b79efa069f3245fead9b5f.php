

<?php $__env->startSection('title', 'Contact us'); ?>

<?php $__env->startSection('content'); ?>
    <div class="b-title-page area-bg area-bg_dark parallax">
        <div class="area-bg__inner">
          <div class="container">
            <div class="row">
              <div class="col-xs-12">
                <!-- <div class="ui-decor-2 ui-decor-2_vert bg-primary"></div> -->
                <h1 class="b-title-page__title">Contact Us</h1>
                <ol class="breadcrumb">
                  <li><a href="/">Home</a></li>
                  <li class="active">Get in Touch</li>
                </ol>
                <!-- end breadcrumb-->
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end b-title-page-->
      
      <section class="section-contact">
        <div class="container">
          <div class="row">
            <div class="col-xs-12">
              <div class="ui-decor-1"><img src="<?php echo e(asset('assetslp/media/general/ui-decor-1.png')); ?>" alt="decor" class="center-block"></div>
              <div class="text-center">
                <h2 class="b-contact__title ui-subtitle-block">Contact us if you need our services. We will be happy to make your events memorable!</h2>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-4 col-lg-offset-0 col-md-6 col-md-offset-3">
              <div data-stellar-background-ratio="0.4" class="b-contact stellar section-texture section-texture_green section-radius">
                <div class="b-contact__name">Address</div>
                <div class="b-contact__info">38-2 Hilton Street, California</div>
                <div class="b-contact__icon icon-map"></div>
              </div>
              <!-- end b-contact-->
            </div>
            <div class="col-lg-4 col-lg-offset-0 col-md-6 col-md-offset-3">
              <div data-stellar-background-ratio="0.4" class="b-contact stellar section-texture section-texture_blue section-radius">
                <div class="b-contact__name">Phone</div>
                <div class="b-contact__info">(+01) 123 456 7890</div>
                <div class="b-contact__icon icon-call-in"></div>
              </div>
              <!-- end b-contact-->
            </div>
            <div class="col-lg-4 col-lg-offset-0 col-md-6 col-md-offset-3">
              <div data-stellar-background-ratio="0.4" class="b-contact stellar section-texture section-texture_grey section-radius">
                <div class="b-contact__name">Email</div>
                <div class="b-contact__info">inform@shahidevents.com</div>
                <div class="b-contact__icon icon-envelope-open"></div>
              </div>
              <!-- end b-contact-->
            </div>
          </div>
        </div>
      </section>


      


      <div class="b-contact-social-net bg-grey text-center">
        <div class="container">
          <div class="row">
            <div class="col-xs-12">
              <ul class="social-net list-inline">
                <li class="social-net__item"><a href="twitter.com" class="social-net__link text-primary_h"><i class="icon fa fa-twitter"></i></a></li>
                <li class="social-net__item"><a href="facebook.com" class="social-net__link text-primary_h"><i class="icon fa fa-facebook"></i></a></li>
                <li class="social-net__item"><a href="plus.google.com" class="social-net__link text-primary_h"><i class="icon fa fa-google-plus"></i></a></li>
                <li class="social-net__item"><a href="instagram.com" class="social-net__link text-primary_h"><i class="icon fa fa-instagram"></i></a></li>
                <li class="social-net__item"><a href="skype.com" class="social-net__link text-primary_h"><i class="icon fa fa-skype"></i></a></li>
                <li class="social-net__item"><a href="behance.com" class="social-net__link text-primary_h"><i class="icon fa fa-behance"></i></a></li>
                <li class="social-net__item"><a href="vimeo.com" class="social-net__link text-primary_h"><i class="icon fa fa-vimeo"></i></a></li>
              </ul>
              <!-- end social-list-->
            </div>
          </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend-new', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel Projects\catering-event-manage-software\resources\views/frontend/contact.blade.php ENDPATH**/ ?>