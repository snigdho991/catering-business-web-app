<?php echo e($slot); ?>

<?php /**PATH H:\Laravel Projects\catering-event-manage-software\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>